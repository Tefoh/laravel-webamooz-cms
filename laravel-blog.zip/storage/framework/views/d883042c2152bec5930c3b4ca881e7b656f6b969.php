 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

 <?php $__env->slot('title'); ?> 
    - صفحه ثبت نام
 <?php $__env->endSlot(); ?>

<main class="bg--white">
    <div class="container">
        <div class="sign-page">
            <h1 class="sign-page__title">ثبت نام در وب‌سایت</h1>

            <form class="sign-page__form">
                <form action="">
                    <input type="text" class="text text--right" placeholder="نام  و نام خانوادگی">
                    <input type="text" class="text text--left" placeholder="شماره موبایل">
                    <input type="text" class="text text--left" placeholder="ایمیل">
                    <input type="text" class="text text--left" placeholder="رمز عبور">
                    <input type="text" class="text text--left" placeholder="تکرار رمز عبور">


                    <button class="btn btn--blue btn--shadow-blue width-100 mb-10">ثبت نام</button>
                    <button type="reset" class="btn btn--red btn--shadow-red width-100 ">ثبت نام</button>
                    <div class="sign-page__footer">
                        <span>در سایت عضوید ؟ </span>
                        <a href="<?php echo e(route('login')); ?>" class="color--46b2f0">صفحه ورود</a>

                    </div>
                </form>
            </form>
        </div>
    </div>
</main>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH /var/www/html/resources/views/register.blade.php ENDPATH**/ ?>