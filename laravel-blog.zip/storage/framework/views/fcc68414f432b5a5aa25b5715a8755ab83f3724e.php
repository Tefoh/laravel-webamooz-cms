<?php if (isset($component)) { $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PanelLayout::class, []); ?>
<?php $component->withName('panel-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title'); ?> 
    - مدیریت کاربران
   <?php $__env->endSlot(); ?>
   <?php $__env->slot('styles'); ?> 
    <link rel="stylesheet" href="<?php echo e(asset('blog/css/style.css')); ?>">
   <?php $__env->endSlot(); ?>
    <div class="breadcrumb">
      <ul>
          <li><a href="<?php echo e(route('dashboard')); ?>" >پیشخوان</a></li>
          <li><a href="<?php echo e(route('users.index')); ?>" class="is-active">کاربران</a></li>
      </ul>
    </div>
    <div class="main-content font-size-13">
        <div class="tab__box">
            <div class="tab__items">
                <a class="tab__item is-active" href="<?php echo e(route('users.index')); ?>">همه کاربران</a>
                <a class="tab__item" href="<?php echo e(route('users.create')); ?>">ایجاد کاربر جدید</a>
            </div>
        </div>
        <div class="d-flex flex-space-between item-center flex-wrap padding-30 border-radius-3 bg-white">
        </div>
        <div class="bg-white table__box">
            <table class="table">
                <thead role="rowgroup">
                <tr role="row" class="title-row">
                    <th>شناسه</th>
                    <th>نام و نام خانوادگی</th>
                    <th>ایمیل</th>
                    <th>موبایل</th>
                    <th>سطح کاربری</th>
                    <th>تاریخ عضویت</th>
                    <th>عملیات</th>
                </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr role="row" class="">
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->mobile); ?></td>
                        <td><?php echo e($user->getRoleInFarsi()); ?></td>
                        <td><?php echo e($user->getCreatedAtInJalali()); ?></td>
                        <td>
                            <?php if(auth()->user()->id !== $user->id && $user->role !== 'admin'): ?>
                            <a href="<?php echo e(route('users.destroy', $user->id)); ?>" onclick="destroyUser(event, <?php echo e($user->id); ?>)" class="item-delete mlg-15" title="حذف"></a>
                            <?php endif; ?>
                            <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="item-edit " title="ویرایش"></a>
                            <form action="<?php echo e(route('users.destroy', $user->id)); ?>" method="post" id="destroy-user-<?php echo e($user->id); ?>">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('delete'); ?>
                            </form>
                        </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($users->links()); ?>

        </div>
    </div>
     <?php $__env->slot('scripts'); ?> 
      <script>
        function destroyUser(event, id) {
          event.preventDefault();
          Swal.fire({
          title: 'ایا مطمئن هستید این کار را میخواهید حذف کنید؟',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: 'rgb(221, 51, 51)',
          cancelButtonColor: 'rgb(48, 133, 214)',
          confirmButtonText: 'بله حذف کن!',
          cancelButtonText: 'کنسل'
        }).then((result) => {
          if (result.isConfirmed) {
            document.getElementById(`destroy-user-${id}`).submit()
          }
        })
        }
      </script>
     <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937)): ?>
<?php $component = $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937; ?>
<?php unset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/panel/users/index.blade.php ENDPATH**/ ?>