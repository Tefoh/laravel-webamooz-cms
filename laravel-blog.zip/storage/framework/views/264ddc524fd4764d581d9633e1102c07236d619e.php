<?php if (isset($component)) { $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PanelLayout::class, []); ?>
<?php $component->withName('panel-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('title'); ?> 
    - ساخت کاربر جدید
   <?php $__env->endSlot(); ?>
  <div class="breadcrumb">
      <ul>
          <li><a href="<?php echo e(route('dashboard')); ?>" title="پیشخوان">پیشخوان</a></li>
          <li><a href="<?php echo e(route('users.index')); ?>" class="">کاربران</a></li>
          <li><a href="<?php echo e(route('users.create')); ?>" class="is-active">ایجاد کاربر جدید</a></li>
      </ul>
    </div>
    <div class="main-content font-size-13">
        <div class="row no-gutters  bg-white">
            <div class="col-12">
                <p class="box__title">ساخت کاربر</p>
                <form action="<?php echo e(route('users.store')); ?>" class="padding-30" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="text" name="name" class="text" placeholder="نام و نام خانوادگی">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <input type="email" name="email" class="text" placeholder="ایمیل">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <input type="text" name="mobile" class="text" placeholder="شماره موبایل">
                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <select class="select" name="role">
                        <option value="user" selected>کاربر عادی</option>
                        <option value="author">نویسنده</option>
                        <option value="admin">مدیر</option>
                    </select>
                    
                    <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <p class="error"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <button class="btn btn-webamooz_net">ساخت</button>
                </form>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937)): ?>
<?php $component = $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937; ?>
<?php unset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/panel/users/create.blade.php ENDPATH**/ ?>