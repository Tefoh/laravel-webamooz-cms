<?php if (isset($component)) { $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PanelLayout::class, []); ?>
<?php $component->withName('panel-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
 <?php $__env->slot('title'); ?> 
  - مدیریت مقالات
 <?php $__env->endSlot(); ?>
 <?php $__env->slot('styles'); ?> 
  <link rel="stylesheet" href="<?php echo e(asset('blog/css/style.css')); ?>">
 <?php $__env->endSlot(); ?>
<div class="breadcrumb">
        <ul>
            <li><a href="<?php echo e(route('dashboard')); ?>">پیشخوان</a></li>
            <li><a href="<?php echo e(route('posts.index')); ?>" class="is-active"> مقالات</a></li>
        </ul>
    </div>
    <div class="main-content">
        <div class="tab__box">
            <div class="tab__items">
                <a class="tab__item is-active" href="<?php echo e(route('posts.index')); ?>">لیست مقالات</a>
                <a class="tab__item " href="<?php echo e(route('posts.create')); ?>">ایجاد مقاله جدید</a>
            </div>
        </div>
        <div class="bg-white padding-20">
            <div class="t-header-search">
                <form action="<?php echo e(route('posts.index')); ?>">
                    <div class="t-header-searchbox font-size-13">
                        <div type="text" class="text search-input__box font-size-13">جستجوی مقاله
                            <div class="t-header-search-content ">
                                <input type="text" class="text" name="search" placeholder="نام مقاله">
                                <button class="btn btn-webamooz_net">جستجو</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="bg-white table__box">
            <table class="table">

                <thead role="rowgroup">
                <tr role="row" class="title-row">
                    <th>شناسه</th>
                    <th>عنوان</th>
                    <th>نویسنده</th>
                    <th>تاریخ ایجاد</th>
                    <th>عملیات</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr role="row" class="">
                        <td><?php echo e($post->id); ?></td>
                        <td><?php echo e($post->title); ?></td>
                        <td><?php echo e($post->user->name); ?></td>
                        <td><?php echo e($post->getCreatedAtInJalali()); ?></td>
                        <td>
                            <a href="<?php echo e(route('posts.destroy', $post->id)); ?>" onclick="destroyPost(event, <?php echo e($post->id); ?>)" class="item-delete mlg-15" title="حذف"></a>
                            <a href="" target="_blank" class="item-eye mlg-15" title="مشاهده"></a>
                            <a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="item-edit" title="ویرایش"></a>
                            <form action="<?php echo e(route('posts.destroy', $post->id)); ?>" method="post" id="destroy-post-<?php echo e($post->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($posts->appends(request()->query())->links()); ?>

        </div>
    </div>
     <?php $__env->slot('scripts'); ?> 
        <script>
            function destroyPost(event, id) {
                event.preventDefault();
                document.getElementById('destroy-post-' + id).submit();
            }
        </script>
     <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937)): ?>
<?php $component = $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937; ?>
<?php unset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/panel/posts/index.blade.php ENDPATH**/ ?>