<?php if (isset($component)) { $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PanelLayout::class, []); ?>
<?php $component->withName('panel-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
 <?php $__env->slot('title'); ?> 
  - مدیریت دسته بندی ها
 <?php $__env->endSlot(); ?>
 <?php $__env->slot('styles'); ?> 
  <link rel="stylesheet" href="<?php echo e(asset('blog/css/style.css')); ?>">
 <?php $__env->endSlot(); ?>
<div class="breadcrumb">
        <ul>
            <li><a href="<?php echo e(route('dashboard')); ?>">پیشخوان</a></li>
            <li><a href="<?php echo e(route('categories.index')); ?>" class="is-active">دسته بندی ها</a></li>
        </ul>
    </div>
    <div class="main-content padding-0 categories">
        <div class="row no-gutters  ">
            <div class="col-8 margin-left-10 margin-bottom-15 border-radius-3">
                <p class="box__title">دسته بندی ها</p>
                <div class="bg-white table__box">
                    <table class="table">
                        <thead role="rowgroup">
                          <tr role="row" class="title-row">
                              <th>شناسه</th>
                              <th>نام دسته بندی</th>
                              <th>نام انگلیسی دسته بندی</th>
                              <th>دسته پدر</th>
                              <th>عملیات</th>
                          </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr role="row" class="">
                                <td><?php echo e($category->id); ?></td>
                                <td><?php echo e($category->name); ?></td>
                                <td><?php echo e($category->slug); ?></td>
                                <td><?php echo e($category->getParentName()); ?></td>
                                <td>
                                    <a href="<?php echo e(route('categories.destroy', $category->id)); ?>" onclick="destroyCategory(event, <?php echo e($category->id); ?>)" class="item-delete mlg-15" title="حذف"></a>
                                    <a href="<?php echo e(route('categories.edit', $category->id)); ?>" class="item-edit " title="ویرایش"></a>
                                    <form action="<?php echo e(route('categories.destroy', $category->id)); ?>" method="POST" id="destroy-category-<?php echo e($category->id); ?>">
                                      <?php echo csrf_field(); ?>
                                      <?php echo method_field('delete'); ?>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                    <?php echo e($categories->links()); ?>

                </div>
            </div>
            <div class="col-4 bg-white">
                  <p class="box__title">ایجاد دسته بندی جدید</p>
                  <form action="<?php echo e(route('categories.store')); ?>" method="POST" class="padding-30">
                      <?php echo csrf_field(); ?>
                      <input type="text" name="name" placeholder="نام دسته بندی" class="text">
                      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                      <input type="text" name="slug" placeholder="نام انگلیسی دسته بندی" class="text">
                      <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                      <p class="box__title margin-bottom-15">انتخاب دسته پدر</p>

                      <select class="select" name="category_id" id="category_id">
                          <option value="">ندارد</option>
                          <?php $__currentLoopData = $parentCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="error"><?php echo e($message); ?></p>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                      <button class="btn btn-webamooz_net">اضافه کردن</button>
                  </form>
            </div>
        </div>
    </div>
 <?php $__env->slot('scripts'); ?> 
  <script>
    function destroyCategory(event, id) {
      event.preventDefault();
      document.getElementById('destroy-category-' + id).submit();
    }
  </script>
 <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937)): ?>
<?php $component = $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937; ?>
<?php unset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/panel/categories/index.blade.php ENDPATH**/ ?>