<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

 <?php $__env->slot('title'); ?> 
    - صفحه اصلی
 <?php $__env->endSlot(); ?>

<main>
    <article class="container article">
        <div class="articles">
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="articles__item">
                <a href="<?php echo e(route('post.show', $post->slug)); ?>" class="articles__link">
                    <div class="articles__img">
                        <img src="<?php echo e($post->getBannerUrl()); ?>" class="articles__img-src">
                    </div>
                    <div class="articles__title">
                        <h2><?php echo e($post->title); ?></h2>
                    </div>
                    <div class="articles__details">
                        <div class="articles__author">نویسنده : <?php echo e($post->user->name); ?></div>
                        <div class="articles__date">تاریخ : <?php echo e($post->getCreatedAtInJalali()); ?></div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>هیچ مقاله ای یافت نشد!</p>
            <?php endif; ?>
        </div>
    </article>
    <?php echo e($posts->appends(request()->query())->links()); ?>

</main>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/landing.blade.php ENDPATH**/ ?>