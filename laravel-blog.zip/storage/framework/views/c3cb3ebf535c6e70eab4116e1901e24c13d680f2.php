 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
 <?php $__env->slot('title'); ?> 
    - صفحه لاگین
 <?php $__env->endSlot(); ?>
<main class="bg--white">
    <div class="container">
        <div class="sign-page">
            <h1 class="sign-page__title">ورود به وب‌سایت</h1>

            <form class="sign-page__form">
                <form action="">
                    <input type="text" class="text text--left" placeholder="شماره یا ایمیل">
                    <input type="pass" class="text text--left" placeholder="رمز عبور">
                    <label class="checkbox text--right">
                        <input type="checkbox" class="checkbox__filter">
                        <span class="checkbox__mark position-relative"></span>
                        مرا بخاطر بسپار
                    </label>
                    <a class="recover-password" href="<?php echo e(route('reset-pass')); ?>">بازیابی رمز عبور</a>
                    <button class="btn btn--blue btn--shadow-blue width-100 ">ورود به سایت</button>
                    <div class="sign-page__footer">
                        <span>کاربر جدید هستید؟</span>
                        <a href="<?php echo e(route('register')); ?>" class="color--46b2f0">صفحه ثبت نام</a>

                    </div>
                </form>
            </form>
        </div>
    </div>
</main>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH /var/www/html/resources/views/login.blade.php ENDPATH**/ ?>