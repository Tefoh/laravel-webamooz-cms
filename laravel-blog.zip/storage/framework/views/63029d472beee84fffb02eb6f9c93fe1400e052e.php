<?php $__env->startSection('main'); ?>
<main class="bg--white">
    <div class="container">
        <div class="sign-page">
            <h1 class="sign-page__title">بازیابی رمز عبور</h1>

            <form class="sign-page__form">
                <form action="">
                    <input type="text" class="text text--left" placeholder="شماره یا ایمیل">

                    <button class="btn btn--blue btn--shadow-blue width-100 ">بازیابی</button>
                    <div class="sign-page__footer">
                        <span>کاربر جدید هستید؟</span>
                        <a href="<?php echo e(route('register')); ?>" class="color--46b2f0">صفحه ثبت نام</a>

                    </div>
                </form>
            </form>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/reset-password.blade.php ENDPATH**/ ?>