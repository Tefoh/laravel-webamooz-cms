<?php if (isset($component)) { $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PanelLayout::class, []); ?>
<?php $component->withName('panel-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
 <?php $__env->slot('title'); ?> 
  - داشبورد
 <?php $__env->endSlot(); ?>
<div class="breadcrumb">
    <ul>
        <li><a href="<?php echo e(route('dashboard')); ?>" title="پیشخوان">پیشخوان</a></li>
    </ul>
    </div>
    <div class="main-content">
        <div class="row no-gutters font-size-13 margin-bottom-10">
            <?php if(auth()->user()->role === 'admin' || auth()->user()->role === 'author'): ?>
            <div class="col-3 padding-20 border-radius-3 bg-white margin-left-10 margin-bottom-10">
                <p>تعداد پست ها</p>
                <p><?php echo e($posts_count); ?> پست</p>
            </div>
            <div class="col-3 padding-20 border-radius-3 bg-white margin-left-10 margin-bottom-10">
                <p>تعداد نظرات</p>
                <p><?php echo e($comments_count); ?> نظر</p>
            </div>
            <?php endif; ?>
            <?php if(auth()->user()->role === 'admin'): ?>
            <div class="col-3 padding-20 border-radius-3 bg-white margin-left-10 margin-bottom-10">
                <p> تعداد کاربران </p>
                <p><?php echo e($users_count); ?> نفر</p>
            </div>
            <div class="col-3 padding-20 border-radius-3 bg-white  margin-bottom-10">
                <p>تعداد دسته بندی ها</p>
                <p><?php echo e($categories_count); ?> نظر</p>
            </div>
            <?php endif; ?>
        </div>

    </div>
 <?php if (isset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937)): ?>
<?php $component = $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937; ?>
<?php unset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/panel/index.blade.php ENDPATH**/ ?>