<?php if (isset($component)) { $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\PanelLayout::class, []); ?>
<?php $component->withName('panel-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
 <?php $__env->slot('title'); ?> 
  - مدیریت نظرات
 <?php $__env->endSlot(); ?>
 <?php $__env->slot('styles'); ?> 
  <link rel="stylesheet" href="<?php echo e(asset('blog/css/style.css')); ?>">
 <?php $__env->endSlot(); ?>
<div class="breadcrumb">
        <ul>
            <li><a href="<?php echo e(route('dashboard')); ?>">پیشخوان</a></li>
            <li><a href="<?php echo e(route('comments.index')); ?>" class="is-active"> نظرات</a></li>
        </ul>
    </div>
    <div class="main-content">
        <div class="tab__box">
            <div class="tab__items">
                <a class="tab__item is-active" href="<?php echo e(route('comments.index')); ?>"> همه نظرات</a>
                <a class="tab__item " href="<?php echo e(route('comments.index', ['approved' => 0])); ?>">نظرات تاییده نشده</a>
                <a class="tab__item " href="<?php echo e(route('comments.index', ['approved' => 1])); ?>">نظرات تاییده شده</a>
            </div>
        </div>


        <div class="bg-white table__box">
            <table class="table">
                <thead role="rowgroup">
                <tr role="row" class="title-row">
                    <th>شناسه</th>
                    <th>ارسال کننده</th>
                    <th>برای</th>
                    <th>دیدگاه</th>
                    <th>تاریخ</th>
                    <th>تعداد پاسخ ها</th>
                    <th>وضعیت</th>
                    <th>عملیات</th>
                </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr role="row" >
                        <td><?php echo e($comment->id); ?></td>
                        <td><?php echo e($comment->user->name); ?></td>
                        <td><?php echo e($comment->post->title); ?></td>
                        <td><?php echo e($comment->content); ?></td>
                        <td><?php echo e($comment->getCreatedAtInJalali()); ?></td>
                        <td><?php echo e($comment->replies_count); ?></td>
                        <td class="<?php echo e($comment->is_approved ? 'text-success' : 'text-error'); ?>"><?php echo e($comment->getStatusInFarsi()); ?></td>
                        <td>
                            <a href="<?php echo e(route('comments.destroy', $comment->id)); ?>" class="item-delete mlg-15" onclick="destroyComment(event, <?php echo e($comment->id); ?>)" title="حذف"></a>
                            <a href="show-comment.html" target="_blank" class="item-eye mlg-15" title="مشاهده"></a>
                            <?php if($comment->is_approved): ?>
                            <a href="<?php echo e(route('comments.update', $comment->id)); ?>" onclick="updateComment(event, <?php echo e($comment->id); ?>)" class="item-reject mlg-15" title="رد"></a>
                            <?php else: ?>
                            <a href="<?php echo e(route('comments.update', $comment->id)); ?>" onclick="updateComment(event, <?php echo e($comment->id); ?>)" class="item-confirm mlg-15" title="تایید"></a>
                            <?php endif; ?>
                            <form action="<?php echo e(route('comments.update', $comment->id)); ?>" method="post" id="update-comment-<?php echo e($comment->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('put'); ?>
                            </form>
                            <form action="<?php echo e(route('comments.destroy', $comment->id)); ?>" method="post" id="destroy-comment-<?php echo e($comment->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('delete'); ?>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
            </table>
            <?php echo e($comments->appends(request()->query())->links()); ?>

        </div>
    </div>
    
     <?php $__env->slot('scripts'); ?> 
        <script>
            function updateComment(event, id) {
                event.preventDefault();
                document.getElementById('update-comment-' + id).submit();
            }
            function destroyComment(event, id) {
                event.preventDefault();
                document.getElementById('destroy-comment-' + id).submit();
            }
        </script>
     <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937)): ?>
<?php $component = $__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937; ?>
<?php unset($__componentOriginal3f2099d480d2c94b04dc25c901d5ef1d43e36937); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/panel/comments/index.blade.php ENDPATH**/ ?>