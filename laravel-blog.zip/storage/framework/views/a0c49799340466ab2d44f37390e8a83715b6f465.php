<?php echo e($slot); ?>

<?php /**PATH /var/www/html/resources/views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>