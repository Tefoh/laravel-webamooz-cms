 <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

 <?php $__env->slot('title'); ?> 
    - صفحه ثبت نام
 <?php $__env->endSlot(); ?>

<main class="bg--white">
    <div class="container">
        <div class="sign-page">
            <h1 class="sign-page__title">ثبت نام در وب‌سایت</h1>

            <form class="sign-page__form" action="<?php echo e(route('register.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div>
                    <input type="text" name="name" class="text text--right" placeholder="نام و نام خانوادگی" />
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="margin-bottom: 1rem;
                                color: #D8000C;
                                text-align: right;"
                        >
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <input type="text" name="mobile" class="text text--left" placeholder="شماره موبایل" />
                    <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="margin-bottom: 1rem;
                                color: #D8000C;
                                text-align: right;"
                        >
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <input type="text" name="email" class="text text--left" placeholder="ایمیل" />
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="margin-bottom: 1rem;
                                color: #D8000C;
                                text-align: right;"
                        >
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <input type="password" name="password" class="text text--left" placeholder="رمز عبور" />
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p style="margin-bottom: 1rem;
                                color: #D8000C;
                                text-align: right;"
                        >
                            <?php echo e($message); ?>

                        </p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div>
                    <input type="password" name="password_confirmation" class="text text--left" placeholder="تکرار رمز عبور" />
                </div>

                <button class="btn btn--blue btn--shadow-blue width-100 mb-10" type="submit">
                    ثبت نام
                </button>
                <div class="sign-page__footer">
                    <span>در سایت عضوید ؟ </span>
                    <a href="<?php echo e(route('login')); ?>" class="color--46b2f0">صفحه ورود</a>

                </div>
            </form>
        </div>
    </div>
</main>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> <?php /**PATH /var/www/html/resources/views/auth/register.blade.php ENDPATH**/ ?>