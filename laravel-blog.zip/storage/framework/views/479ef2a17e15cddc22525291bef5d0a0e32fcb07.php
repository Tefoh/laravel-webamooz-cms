<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

 <?php $__env->slot('title'); ?> 
    - صفحه پست <?php echo e($post->title); ?>

 <?php $__env->endSlot(); ?>

<main>
    <div class="container article">
        <article class="single-page">
            <div class="breadcrumb">
                <ul class="breadcrumb__ul">
                    <li class="breadcrumb__item">
                    <a href="<?php echo e(route('landing')); ?>" class="breadcrumb__link">
                    بخش مقالات
                    </a>
                    </li>
                    <li class="breadcrumb__item">
                    <a href="<?php echo e(route('post.show', $post->slug)); ?>" class="breadcrumb__link">
                    <?php echo e($post->title); ?>

                    ‌</a></li>
                </ul>
            </div>
            <div class="single-page__title">
                <h1 class="single-page__h1"><?php echo e($post->title); ?></h1>
                <?php if(auth()->guard()->check()): ?>
                <span class="single-page__like <?php if($post->is_user_liked): ?> single-page__like--is-active <?php endif; ?>"></span>
                <?php endif; ?>
            </div>
            <div class="single-page__details">
                <div class="single-page__author">نویسنده : <?php echo e($post->user->name); ?></div>
                <div class="single-page__date">تاریخ : <?php echo e($post->getCreatedAtInJalali()); ?></div>
            </div>
            <div class="single-page__img">
                <img class="single-page__img-src" src="<?php echo e($post->getBannerUrl()); ?>" alt="">
            </div>
            <div class="single-page__content">
                <?php echo $post->content; ?>

            </div>
            <div class="single-page__tags">
                <ul class="single-page__tags-ul">
                    <?php $__currentLoopData = $post->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="single-page__tags-li"><a href="<?php echo e(route('category.show', $category->slug)); ?>" class="single-page__tags-link"><?php echo e($category->name); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

        </article>
    </div>
    <div class="container">
        <div class="comments" id="comments">
            <?php if(auth()->guard()->check()): ?>
                <div class="comments__send">
                    <div class="comments__title">
                        <h3 class="comments__h3"> دیدگاه خود را بنویسید </h3>
                        <span class="comments__count">  نظرات ( <?php echo e($post->comments_count); ?> ) </span>
                    </div>
                    <form action="<?php echo e(route('comment.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                        <input type="hidden" name="comment_id" value="" id="reply-input">
                        <textarea class="comments__textarea" name="content" placeholder="بنویسید"></textarea>
                        <button class="btn btn--blue btn--shadow-blue">ارسال نظر</button>
                        <button class="btn btn--red btn--shadow-red">انصراف</button>
                    </form>
                </div>
            <?php else: ?>
                <p>شما برای ارسال نظر باید اول وارد سایت شوید</p>
            <?php endif; ?>
            <div class="comments__list">
                <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $__env->make('comments.comment', ['comment' => $comment], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</main>
 <?php $__env->slot('scripts'); ?> 
    <script>
        function setReplyValue(id) {
            document.getElementById('reply-input').value = id;
        }
            
        $(".single-page__like").on("click", function () {
            fetch('<?php echo e(route("like.post", $post->slug)); ?>', {
                method: 'post',
                headers: {
                    'X-CSRF-Token': '<?php echo e(csrf_token()); ?>'
                }
            }).then((response) => {
                if(response.ok) {
                    $(this).toggleClass("single-page__like--is-active");
                }
            })
            
        })
    </script>
 <?php $__env->endSlot(); ?>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/post.blade.php ENDPATH**/ ?>