<ul>
    <li class="item-li i-dashboard <?php if(request()->is('dashboard')): ?> is-active <?php endif; ?>"><a href="<?php echo e(route('dashboard')); ?>">پیشخوان</a></li>
    <?php if(auth()->user()->role === 'admin'): ?>
    <li class="item-li i-users <?php if(request()->is('panel/users') || request()->is('panel/users/*')): ?> is-active <?php endif; ?>"><a href="<?php echo e(route('users.index')); ?>"> کاربران</a></li>
    <li class="item-li i-categories <?php if(request()->is('panel/categories') || request()->is('panel/categories/*')): ?> is-active <?php endif; ?>"><a href="<?php echo e(route('categories.index')); ?>">دسته بندی ها</a></li>
    <?php endif; ?>
    <?php if(auth()->user()->role === 'admin' || auth()->user()->role === 'author'): ?>
    <li class="item-li i-articles <?php if(request()->is('panel/posts') || request()->is('panel/posts/*')): ?> is-active <?php endif; ?>"><a href="<?php echo e(route('posts.index')); ?>">مقالات</a></li>
    <?php endif; ?>
    <?php if(auth()->user()->role === 'admin'): ?>
    <li class="item-li i-comments <?php if(request()->is('panel/comments') || request()->is('panel/comments/*')): ?> is-active <?php endif; ?>"><a href="<?php echo e(route('comments.index')); ?>"> نظرات</a></li>
    <?php endif; ?>
    <li class="item-li i-user__inforamtion <?php if(request()->is('profile')): ?> is-active <?php endif; ?>"><a href="<?php echo e(route('profile')); ?>">اطلاعات کاربری</a></li>
</ul><?php /**PATH /var/www/html/resources/views/_partials/panel-sidebar.blade.php ENDPATH**/ ?>