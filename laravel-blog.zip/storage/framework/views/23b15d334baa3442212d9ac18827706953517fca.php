<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'Laravel'): ?>
<img src="<?php echo e(asset('blog/img/weblogo.png')); ?>" style="height: auto !important; width: 100% !important;" class="logo" alt="Laravel Logo">
<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH /var/www/html/resources/views/vendor/mail/html/header.blade.php ENDPATH**/ ?>