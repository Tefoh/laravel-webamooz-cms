<?php

namespace App\View\Components;

use Illuminate\View\Component;

class PanelLayout extends Component
{
    public function render()
    {
        return view('layouts.panel');
    }
}
